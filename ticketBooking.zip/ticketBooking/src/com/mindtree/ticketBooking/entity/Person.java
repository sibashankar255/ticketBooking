package com.mindtree.ticketBooking.entity;

public class Person 
{
	int personId;
	String personName;
	int accountBalance;
	
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Person(int personId, String personName, int accountBalance) {
		super();
		this.personId = personId;
		this.personName = personName;
		this.accountBalance = accountBalance;
	}


	@Override
	public String toString() {
		return "Person [personId=" + personId + ", personName=" + personName + ", accountBalance=" + accountBalance
				+ "]";
	}
	public int getPersonId() {
		return personId;
	}
	public void setPersonId(int personId) {
		this.personId = personId;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public int getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}
	
}
