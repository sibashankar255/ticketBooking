package com.mindtree.ticketBooking.entity;

public class Flight 
{
	private int flightId;
	private String flightName;
	private int ticketCost;
	
	
	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	

	public Flight(int flightId, String flightName, int ticketCost) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.ticketCost = ticketCost;
	}




	@Override
	public String toString() {
		return "Flight [flightId=" + flightId + ", flightName=" + flightName + ", ticketCost=" + ticketCost + "]";
	}




	public int getFlightId() {
		return flightId;
	}




	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}




	public String getFlightName() {
		return flightName;
	}




	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}




	public int getTicketCost() {
		return ticketCost;
	}




	public void setTicketCost(int ticketCost) {
		this.ticketCost = ticketCost;
	}



	
}
