package com.mindtree.ticketBooking.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcConnection 
{
	private static final String url = "jdbc:mysql://localhost:3306/test";
	private static final String uname = "root";
	private static final String password = "Welcome123";
	public static Connection getConnection()
	{
		Connection connection = null;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(url, uname, password);
		} 
		catch (ClassNotFoundException e) 
		{
			System.err.println(e.getMessage());
			//e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			System.err.println(e.getMessage());
			//e.printStackTrace();
		}	
		return connection;
	}
	public static String closeConnection(Connection connection)
	{
		String result ="";
		try 
		{
			connection.close();
			result = "Connection closed sucessfully";
		} 
		catch (SQLException e) 
		{
			result =e.getMessage();
			//e.printStackTrace();
		}
		return result;
	}
}
