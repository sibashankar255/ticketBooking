package com.mindtree.ticketBooking.exception.service;

import com.mindtree.ticketBooking.exception.ApplicationException;

public class ApplicationExceptionService extends ApplicationException
{

	public ApplicationExceptionService() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApplicationExceptionService(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public ApplicationExceptionService(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ApplicationExceptionService(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ApplicationExceptionService(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
