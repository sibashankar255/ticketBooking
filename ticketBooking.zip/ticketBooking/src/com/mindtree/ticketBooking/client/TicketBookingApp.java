package com.mindtree.ticketBooking.client;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.mindtree.ticketBooking.entity.Flight;
import com.mindtree.ticketBooking.entity.Person;
import com.mindtree.ticketBooking.exception.ApplicationException;
import com.mindtree.ticketBooking.exception.service.ApplicationExceptionService;
import com.mindtree.ticketBooking.service.FlightService;
import com.mindtree.ticketBooking.service.PersonService;
import com.mindtree.ticketBooking.service.serviceImpl.FlightServiceImpl;
import com.mindtree.ticketBooking.service.serviceImpl.PersonServiceImpl;
public class TicketBookingApp 
{
    static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) 
	{
		Flight flight=null;
		Person person=null;
		FlightService flightservice = new FlightServiceImpl();
		PersonService personservice = new PersonServiceImpl();
		boolean flag = true;
		do
		{
			System.out.println("1.insert a flight");
			System.out.println("2.insert a person");
			System.out.println("3.assign flight to a person");
			System.out.println("4.display all fligths");
			System.out.println("5.display all persons whose balance>50000");
			System.out.println("6.exit");
			System.out.println("enter a choice");
			int switchInteger = sc.nextInt();sc.nextLine();
			switch(switchInteger)
			{
			case 1:
				System.out.println("enter fligth id");
				int flightId = sc.nextInt();sc.nextLine();
				System.out.println("enter flight name");
				String flightName = sc.nextLine();
				System.out.println("enter flight ticket cost");
				int ticketCost = sc.nextInt();sc.nextLine();
				flight = new Flight(flightId, flightName, ticketCost);
				
				try 
				{
					String flightinsertResult = flightservice.insertFlight(flight);
					System.out.println(flightinsertResult);
				} 
				catch (ApplicationExceptionService e) 
				{
					System.out.println(e.getMessage());
				}
				
				break;
			case 2:
				System.out.println("enter person id");
				int personId = sc.nextInt();sc.nextLine();
				System.out.println("enter person name");
				String personName = sc.nextLine();
				System.out.println("enter account balance");
				int accountBalance = sc.nextInt();
				person = new Person(personId,personName,accountBalance);
				try 
				{
					String personinsertresult = personservice.insertPerson(person);
					System.out.println(personinsertresult);
				} 
				catch (ApplicationExceptionService e) 
				{
					System.err.println(e.getMessage());
				}
				break;
			case 3:
				System.out.println("enter person name:");
				String assignPerson = sc.nextLine();
				System.out.println("enter flight:");
				String assignFlight = sc.nextLine();
				///////////fetching flight cost//////////////////
				int flightCost=0;
				try 
				{
					flightCost=flightservice.getFlightCost(assignFlight);
				} 
				catch (ApplicationExceptionService e1) 
				{
					System.err.println(e1.getMessage());
				}
				/////////assign flight to persson//////////////////
				String assign="";
				try 
				{
					assign = personservice.assignFlight(assignPerson,assignFlight,flightCost);
					System.out.println(assign);
				} 
				catch (ApplicationExceptionService e1) 
				{
					System.err.println(e1.getMessage());
				}
				//////////fetching person's account balance////////
				int accountbal = 0;
				try 
				{
					accountbal = personservice.getPersonBalance(assignPerson);
				} 
				catch (ApplicationExceptionService e1) 
				{
					System.err.println(e1.getMessage());
				}
				
				int updatebalance=accountbal - flightCost;
				//////////update person's account balance//////////
					try 
					{
						String updateaccount = personservice.updateAccount(assignPerson,updatebalance);
						System.out.println(updateaccount);
					} 
					catch (ApplicationExceptionService e) 
					{
						System.err.println(e.getMessage());
					}
				
				break;
			case 4:
				System.out.println("display all flights");
				List<Flight> flightlist = new ArrayList<>();
				
				try 
				{
					flightlist = flightservice.displayAllFlight(flightlist);
				} 
				catch (ApplicationExceptionService e) 
				{
					System.err.println(e.getMessage());
				}
				
				for (Flight flight2 : flightlist) 
				{
					System.out.println(flight2.toString());
				}
				
				break;
			case 5:
				System.out.println("display persons whose account balance>50000");
				List<Person> personlist = new ArrayList<>();
				
				try 
				{
					personlist = personservice.displayPersonWithHigherBalance(personlist);
				} 
				catch (ApplicationExceptionService e) 
				{
					System.err.println(e.getMessage());
				}
				for (Person person2 : personlist) 
				{
					System.out.println(person2.toString());
				}
				
				break;
			case 6:
				flag = false;
				break;
			default:
				flag = false;
				break;
			}
		}
		while(flag);
	}
}
