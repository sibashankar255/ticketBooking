package com.mindtree.ticketBooking.service;

import java.util.List;

import com.mindtree.ticketBooking.entity.Flight;
import com.mindtree.ticketBooking.exception.service.ApplicationExceptionService;

public interface FlightService 
{

	public String insertFlight(Flight flight) throws ApplicationExceptionService;

	public List<Flight> displayAllFlight(List<Flight> flightlist) throws ApplicationExceptionService;

	public int getFlightCost(String assignFlight) throws ApplicationExceptionService;

}
