package com.mindtree.ticketBooking.service;

import java.util.List;

import com.mindtree.ticketBooking.entity.Person;
import com.mindtree.ticketBooking.exception.service.ApplicationExceptionService;

public interface PersonService 
{

	public String insertPerson(Person person) throws ApplicationExceptionService;

	public String assignFlight(String assignPerson, String assignFlight, int flightCost) throws ApplicationExceptionService;

	public String updateAccount(String assignPerson, int updatebalance) throws ApplicationExceptionService;

	public int getPersonBalance(String assignPerson) throws ApplicationExceptionService;

	public List<Person> displayPersonWithHigherBalance(List<Person> personlist) throws ApplicationExceptionService;

}
