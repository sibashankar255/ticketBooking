package com.mindtree.ticketBooking.service.serviceImpl;

import java.util.List;

import com.mindtree.ticketBooking.dao.PersonDao;
import com.mindtree.ticketBooking.dao.daoimpl.PersonDaoImpl;
import com.mindtree.ticketBooking.entity.Person;
import com.mindtree.ticketBooking.exception.dao.ApplicationExceptionDao;
import com.mindtree.ticketBooking.exception.service.ApplicationExceptionService;
import com.mindtree.ticketBooking.service.PersonService;

public class PersonServiceImpl implements PersonService
{
	PersonDao persondao = new PersonDaoImpl();
	@Override
	public String insertPerson(Person person) throws ApplicationExceptionService 
	{
		String personResult ="";
		try 
		{
			personResult = persondao.insertPerson(person);
		} 
		catch (ApplicationExceptionDao e) 
		{
			throw new ApplicationExceptionService(e.getMessage(),e);
		}
		return personResult;
	}
	
	@Override
	public String assignFlight(String assignPerson, String assignFlight, int flightCost) throws ApplicationExceptionService 
	{
		String assign="";
		try 
		{
			assign = persondao.assignFlight(assignPerson,assignFlight,flightCost);
		} 
		catch (ApplicationExceptionDao e) 
		{
			throw new ApplicationExceptionService(e);
		}
		return assign;
	}

	@Override
	public String updateAccount(String assignPerson, int updatebalance) throws ApplicationExceptionService 
	{
		String update="";
		try 
		{
			update = persondao.updateAccount(assignPerson,updatebalance);
		} 
		catch (ApplicationExceptionDao e) 
		{
			throw new ApplicationExceptionService(e.getMessage(),e); 
		}
		return update;
	}

	@Override
	public int getPersonBalance(String assignPerson) throws ApplicationExceptionService 
	{
		int accountBalance = 0;
		try 
		{
			accountBalance = persondao.getPersonBalance(assignPerson);
		} 
		catch (ApplicationExceptionDao e) 
		{
			throw new ApplicationExceptionService(e.getMessage(),e);
		}
		return accountBalance;
	}

	@Override
	public List<Person> displayPersonWithHigherBalance(List<Person> personlist) throws ApplicationExceptionService 
	{
		try 
		{
			personlist = persondao.displayPersonWithHigherBalance(personlist);
		} 
		catch (ApplicationExceptionDao e) 
		{
			throw new ApplicationExceptionService(e.getMessage(),e);
		
		}
		return personlist;
	}

}