package com.mindtree.ticketBooking.service.serviceImpl;

import java.util.List;

import com.mindtree.ticketBooking.dao.FlightDao;
import com.mindtree.ticketBooking.dao.daoimpl.FlightDaoImpl;
import com.mindtree.ticketBooking.entity.Flight;
import com.mindtree.ticketBooking.exception.dao.ApplicationExceptionDao;
import com.mindtree.ticketBooking.exception.service.ApplicationExceptionService;
import com.mindtree.ticketBooking.service.FlightService;

public class FlightServiceImpl implements FlightService
{
	FlightDao flightdao = new FlightDaoImpl();
	
	@Override
	public String insertFlight(Flight flight) throws ApplicationExceptionService 
	{
		String flightResult="";
		try 
		{
			flightResult = flightdao.insertFlight(flight);
		} 
		catch (ApplicationExceptionDao e) 
		{
			throw new ApplicationExceptionService(e);
		}
		return flightResult;
	}
	
	@Override
	public List<Flight> displayAllFlight(List<Flight> flightlist) throws ApplicationExceptionService 
	{
		try 
		{
			flightlist = flightdao.displayAllFlight(flightlist);
		} 
		catch (ApplicationExceptionDao e) 
		{
			throw new ApplicationExceptionService(e.getMessage(),e);		
		}
		return flightlist;
	}

	@Override
	public int getFlightCost(String assignFlight) throws ApplicationExceptionService 
	{
		int flightCost=0;
		try 
		{
			flightCost=flightdao.getFlightCost(assignFlight);
		} 
		catch (ApplicationExceptionDao e) 
		{
			throw new ApplicationExceptionService(e.getMessage(),e);
		}
		return flightCost;
	}
}
