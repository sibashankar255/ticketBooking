package com.mindtree.ticketBooking.dao.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.mindtree.ticketBooking.dao.FlightDao;
import com.mindtree.ticketBooking.entity.Flight;
import com.mindtree.ticketBooking.exception.dao.ApplicationExceptionDao;
import com.mindtree.ticketBooking.exception.dao.custom.DuplicateFlightException;
import com.mindtree.ticketBooking.exception.dao.custom.FlightNotFoundException;
import com.mindtree.ticketBooking.utility.JdbcConnection;

public class FlightDaoImpl implements FlightDao
{

	@Override
	public String insertFlight(Flight flight) throws ApplicationExceptionDao 
	{
		Connection connection = JdbcConnection.getConnection();
		if(connection!=null)
		{
			System.out.println("connected");
		}
		String query = "insert into flight values(?,?,?)";
		int result = 0;
		try 
		{
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, flight.getFlightId());
			statement.setString(2, flight.getFlightName());
			statement.setInt(3, flight.getTicketCost());
			result=statement.executeUpdate();
			if(result>0)
				return "insert successful";
			else
				throw new DuplicateFlightException("Flight already present");
		} 
		catch (SQLException e) 
		{
			throw new ApplicationExceptionDao("error in inserting",e);
		}
		finally
		{
			JdbcConnection.closeConnection(connection);
		}
		
	}

	@Override
	public List<Flight> displayAllFlight(List<Flight> flightlist) throws ApplicationExceptionDao 
	{
		Connection connection = JdbcConnection.getConnection();
		if(connection!=null)
		{
			System.out.println("connection establish");
		}
		String query = "select * from flight";
		try 
		{
			Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery(query);
			while(result.next())
			{
				Flight f = new Flight();
				f.setFlightId(result.getInt(1));
				f.setFlightName(result.getString(2));
				f.setTicketCost(result.getInt(3));
				flightlist.add(f);
			}	
		} 
		catch (SQLException e) 
		{
			throw new ApplicationExceptionDao(e.getMessage(),e);
		}
		finally
		{
			JdbcConnection.closeConnection(connection);
		}
		return flightlist;
			
	}
	@Override
	public int getFlightCost(String assignFlight) throws ApplicationExceptionDao 
	{
		Connection connection = JdbcConnection.getConnection();
		if(connection!=null)
		{
			System.out.println("connection establish");
		}
		String query = "select * from flight where flightname=?";
		int flightCost=0;
		try 
		{
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, assignFlight);
			ResultSet result = statement.executeQuery();
			if(result.next())
			{
				do
				{
					flightCost = result.getInt(3);
				}
				while(result.next());
			}
			if(flightCost!=0)
			{
				System.out.println("flight cost fetched");
			}
			else
			{
				throw new FlightNotFoundException("flight not found");
			}
		} 
		catch (SQLException e) 
		{
			throw new ApplicationExceptionDao(e.getMessage(),e);
		}	
		finally
		{
			JdbcConnection.closeConnection(connection);
		}
		return flightCost;
	}
}
