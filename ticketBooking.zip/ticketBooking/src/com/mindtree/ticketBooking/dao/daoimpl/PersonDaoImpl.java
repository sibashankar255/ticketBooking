package com.mindtree.ticketBooking.dao.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.mindtree.ticketBooking.dao.PersonDao;
import com.mindtree.ticketBooking.entity.Person;
import com.mindtree.ticketBooking.exception.dao.ApplicationExceptionDao;
import com.mindtree.ticketBooking.exception.dao.custom.DuplicatePersonException;
import com.mindtree.ticketBooking.exception.dao.custom.FlightNotFoundException;
import com.mindtree.ticketBooking.exception.dao.custom.PersonNotFoundException;
import com.mindtree.ticketBooking.utility.JdbcConnection;

public class PersonDaoImpl implements PersonDao {

	@Override
	public String insertPerson(Person person) throws ApplicationExceptionDao 
	{
		Connection connection = JdbcConnection.getConnection();
		if (connection != null) {
			System.out.println("connection establish");
		}
		String query = "insert into person values(?, ?, ?)";
		int result = 0;
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, person.getPersonId());
			statement.setString(2, person.getPersonName());
			statement.setInt(3, person.getAccountBalance());
			result = statement.executeUpdate();
			if (result > 0)
				return "insert successful";
			else
				throw new DuplicatePersonException("person already present");
		} 
		catch (SQLException e) 
		{
			throw new ApplicationExceptionDao("error in inserting", e);
		}
		finally
		{
			JdbcConnection.closeConnection(connection);
		}
	}

	@Override
	public String assignFlight(String assignPerson, String assignFlight, int flightCost) throws ApplicationExceptionDao 
	{
		Connection connection = JdbcConnection.getConnection();
//		if (connection != null) 
//		{
//			System.out.println("connection establish");
//		}
		try {
			int result = 0;
			String query = "insert into booking values(?,?)";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, assignFlight);
			statement.setString(2, assignPerson);
			result = statement.executeUpdate();
			if (result > 0)
				return "flight assigned to a person";
			else
				throw new FlightNotFoundException("flight not assign");
		} 
		catch (SQLException | FlightNotFoundException e) 
		{
			throw new ApplicationExceptionDao( e);
		}
		finally
		{
			JdbcConnection.closeConnection(connection);
		}
	}

	@Override
	public String updateAccount(String assignPerson, int updatebalance) throws ApplicationExceptionDao 
	{
		Connection connection = JdbcConnection.getConnection();
		if (connection != null) {
			System.out.println("connection establish");
		}
		int result=0;
		String query = "update person set balance=? where personname = ?";
		try 
		{
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, updatebalance);
			statement.setString(2, assignPerson);
			
			result = statement.executeUpdate();
			if(result>0)
				return  "account balance updated";
			else
				throw new PersonNotFoundException("No person is available on this name");
			
		} 
		catch (SQLException | PersonNotFoundException e) 
		{
			throw new ApplicationExceptionDao(e.getMessage(),e);
		}
		finally
		{
			JdbcConnection.closeConnection(connection);
		}
	}

	@Override
	public int getPersonBalance(String assignPerson) throws ApplicationExceptionDao 
	{
		Connection connection = JdbcConnection.getConnection();
		String query = "select * from person where personname=?";
		int accountBalance=0;
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, assignPerson);
			ResultSet result = statement.executeQuery();
			
			if(result.next())
			{
				do
				{
					accountBalance = result.getInt(3);
				}
				while(result.next());
			}
			if(accountBalance!=0)
			{
				System.out.println("flight cost fetched");
			}
			else
			{
				throw new PersonNotFoundException("flight not found");
			}
		
		} 
		catch (SQLException | PersonNotFoundException e) 
		{
			throw new ApplicationExceptionDao(e.getMessage(),e);
			
		}
		finally
		{
			JdbcConnection.closeConnection(connection);
		}
		return accountBalance;
	}

	@Override
	public List<Person> displayPersonWithHigherBalance(List<Person> personlist) throws ApplicationExceptionDao 
	{
		Connection connection = JdbcConnection.getConnection();
		if(connection!=null)
		{
			System.out.println("connection establish");
		}
		String query = "select * from person where balance>50000";
		
		Statement statement;
		try 
		{
			statement = connection.createStatement();
			ResultSet result = statement.executeQuery(query);
			while(result.next())
			{
				Person p = new Person();
				p.setPersonId(result.getInt(1));
				p.setPersonName(result.getString(2));
				p.setAccountBalance(result.getInt(3));
				personlist.add(p);
			}
		} 
		catch (SQLException e) 
		{
			throw new ApplicationExceptionDao(e.getMessage(),e);
		}
		finally
		{
			JdbcConnection.closeConnection(connection);
		}
		
		return personlist;
	}
}
