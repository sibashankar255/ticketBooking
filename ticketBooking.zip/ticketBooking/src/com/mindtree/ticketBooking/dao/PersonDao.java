package com.mindtree.ticketBooking.dao;

import java.util.List;

import com.mindtree.ticketBooking.entity.Person;
import com.mindtree.ticketBooking.exception.dao.ApplicationExceptionDao;

public interface PersonDao {

	public String insertPerson(Person person) throws ApplicationExceptionDao;

	public String assignFlight(String assignPerson, String assignFlight, int flightCost) throws ApplicationExceptionDao;

	public String updateAccount(String assignPerson, int updatebalance) throws ApplicationExceptionDao;

	public int getPersonBalance(String assignPerson) throws ApplicationExceptionDao;

	public List<Person> displayPersonWithHigherBalance(List<Person> personlist) throws ApplicationExceptionDao;

}
