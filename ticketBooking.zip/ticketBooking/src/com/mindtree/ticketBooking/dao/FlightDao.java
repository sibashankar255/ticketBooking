package com.mindtree.ticketBooking.dao;

import java.util.List;

import com.mindtree.ticketBooking.entity.Flight;
import com.mindtree.ticketBooking.exception.dao.ApplicationExceptionDao;

public interface FlightDao 
{

	public String insertFlight(Flight flight) throws ApplicationExceptionDao;

	public List<Flight> displayAllFlight(List<Flight> flightlist) throws ApplicationExceptionDao;

	public int getFlightCost(String assignFlight) throws ApplicationExceptionDao;

}
